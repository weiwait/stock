<?php
/**
 * Created by PhpStorm.
 * User: weiwait
 * Date: 2018/1/16
 * Time: 16:17
 */

namespace db;


use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{

}