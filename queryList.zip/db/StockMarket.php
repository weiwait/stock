<?php
/**
 * Created by PhpStorm.
 * User: weiwait
 * Date: 2018/1/16
 * Time: 17:24
 */

namespace db;


use Illuminate\Database\Eloquent\Model;

class StockMarket extends Model
{
    public $table = 'stock_markets_2016';

    public $timestamps = false;
}