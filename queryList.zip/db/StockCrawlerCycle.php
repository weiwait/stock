<?php
/**
 * Created by PhpStorm.
 * User: weiwait
 * Date: 2018/1/17
 * Time: 10:36
 */

namespace db;


use Illuminate\Database\Eloquent\Model;

class StockCrawlerCycle extends Model
{
    public $timestamps = false;
}